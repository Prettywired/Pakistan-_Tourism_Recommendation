const mongoose=require('mongoose');
const citySchema=new mongoose.Schema({
name: String,
country:String,
user: { type: mongoose.SchemaTypes.ObjectId, ref: 'Users' }
})

const Cities= mongoose.model('Cities', citySchema);
module.exports=Cities;