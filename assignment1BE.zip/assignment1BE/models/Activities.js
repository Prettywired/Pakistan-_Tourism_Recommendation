// /* backend Activities.js */ const mongoose=require('mongoose');
// const activitySchema=new mongoose.Schema({
//     type: String,
//     description: String,
//     landmark: {type: mongoose.SchemaTypes.ObjectId, ref:'Landmarks'},
//     city: {type: mongoose.SchemaTypes.ObjectId, ref:'Cities'},
//     image: String
//     })
    
//     const Activities= mongoose.model('Activities', activitySchema);
//     module.exports=Activities;

/* backend Activities.js */ const mongoose=require('mongoose');
const activitySchema=new mongoose.Schema({
    type: String,
    description: String,
    image: String
    })
    
    const Activities= mongoose.model('Activities', activitySchema);
    module.exports=Activities;