const Users = require("../models/User");
const Cities = require("../models/City");
var express = require("express");
var router = express.Router();

router.post("/getByCityName", async (req, res) => {
    try {
        const city = await Cities.findOne({ name: req.body.name})
        if (!city) return res.json({ msg: "CITY NOT FOUND" })
        res.json({ msg: "CITY FOUND", data: city })
    } catch (error) {
        console.error(error)
    }
});





router.use((req, res, next) => {
    if (!req.user.admin) return res.json({ msg: "NOT ADMIN" })
    else next()
}) //since we are using a middleware here, all further requests can only be accessed via admin



router.post("/addCity", async (req, res) => {
    try {
        const user = await Users.findOne({ email: req.body.email })
       
        if (!user) return res.json({ msg: "USER NOT FOUND" })
        let checkCity=/^[a-zA-Z]+$/
        if(!checkCity.test(req.body.name)){
return res.json({msg: "City name needs to be in letters."})
        }
        await Cities.create({ ...req.body, user: user._id })
        res.json({ msg: "CITY ADDED" })
    } catch (error) {
        console.error(error)
    }
});

router.post("/deleteByName", async (req, res) => {
    try {
        const city = await Cities.findOne({ name: req.body.name })
        if (!city) return res.json({ msg: "CITY NOT FOUND" })
        await Cities.deleteOne({ name: req.body.name})
        res.json({ msg: "CITY DELETED" })
    } catch (error) {
        console.error(error)
    }
});

module.exports = router
